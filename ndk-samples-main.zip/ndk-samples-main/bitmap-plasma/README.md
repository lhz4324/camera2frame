# Bitmap Plasma

Bitmap Plasma is an Android sample that uses JNI to render a plasma effect in an
Android
[Bitmap](http://developer.android.com/reference/android/graphics/Bitmap.html)
from C code.

## Screenshots

![screenshot](screenshot.png)
