# Hello JNI Callback

This sample is an add-on to Hello JNI sample to demonstrate calling back to Java
from C code

- create a java class instance from C code
- call java class static and non-static member functions

## Screenshots

![screenshot](screenshot.png)
