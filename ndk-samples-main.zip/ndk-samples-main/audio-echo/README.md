# Sample removed

This sample has been removed because the API it demonstrated (OpenSLES) is
deprecated. New apps should instead use [Oboe], which has its own samples.

[Oboe]: https://github.com/google/oboe
