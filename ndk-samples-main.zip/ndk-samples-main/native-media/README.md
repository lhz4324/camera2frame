# Sample removed

This sample has been removed because we no longer recommend using OpenMAX AL in
new code. See the `native-codec` sample instead for an example of how to use the
Android Media APIs.
