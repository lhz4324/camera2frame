# Native Codec

Native Codec is an Android C++ sample that uses the Native Media Codec API to
play a video.

encoded stream files are under app/src/main/assets/clips one file testfile.mp4
is provided as an example. To add your own files:

- copy your stream file into app/src/main/assets/
- add your file name to res/strings.xml, "source_array"
- compile and run app
- from android device, select your stream

## Screenshots

![screenshot](screenshot.png)
