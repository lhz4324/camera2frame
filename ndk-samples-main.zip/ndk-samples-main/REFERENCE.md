Android Studio/Gradle DSL References

| Name           | Function            | Type | Options      | Default |
| -------------- | ------------------- | :--: | ------------ | ------- |
| debuggable     | Debugging Java code | bool | true / false |         |
| ndk.debuggable | Debugging JNI code  | bool | true / false |         |

Notation: dot(".") notation is same as closure ("{}") notation
