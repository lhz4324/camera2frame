# Sample removed

This sample was removed because it did not demonstrate any Android NDK features
not already shown by other samples.
