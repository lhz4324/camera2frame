#!/system/bin/sh
LD_HWASAN=1 exec "$@"
