# Hello JNI

Hello JNI is an Android sample that uses JNI to call C code from a Android Java
Activity.

## Screenshots

![screenshot](screenshot.png)
