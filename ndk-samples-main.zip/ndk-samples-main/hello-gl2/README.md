# Hello GL2

Hello GL2 is an Android C++ sample that draws a triangle using GLES 2.0 API.

It uses JNI to do the rendering in C++ over a
[GLSurfaceView](http://developer.android.com/reference/android/opengl/GLSurfaceView.html)
created from a regular Android Java Activity.

## Screenshots

![screenshot](screenshot.png)
