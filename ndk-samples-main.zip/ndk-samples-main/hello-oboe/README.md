# Sample removed

This sample has been removed the upstream [Oboe] repository has is own (much
better!) samples.

[Oboe]: https://github.com/google/oboe
