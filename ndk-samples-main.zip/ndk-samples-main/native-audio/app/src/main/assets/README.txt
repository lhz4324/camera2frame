File background.mp3 ("Background for talking but don't") is
copyright 2008 by Glenn Kasten and is licensed under a
Creative Commons Attribution 3.0 Unported License:
  http://creativecommons.org/licenses/by/3.0/
