# Sample removed

This sample has been removed because the Android Neural Networks API has been
deprecated. Apps should instead use TensorFlow Lite. For for information, see
the [NNAPI Migration Guide].

[NNAPI Migration Guide]: https://developer.android.com/ndk/guides/neuralnetworks/migration-guide
