# Sensor-Graph

Sensor graph is a C++ Android sample that read current accelerometer values and
draw them using OpenGL.

It demonstrate usage of the following Native C++ API:

- [Sensors](http://developer.android.com/ndk/reference/group___sensor.html)
- [Assets](http://developer.android.com/ndk/reference/group___asset.html)

## Screenshots

![screenshot](screenshot.png)
