package com.gtk.camera2frame.model;

public enum EventType {
    NONE,                // 无事件
    START_PREVIEW,      // 启动预览
    PICTURE,            // 拍照
    RECORD,             // 录像
    PICTURE_COMMOND_AI, // AI指令拍照
    PICTURE_FOR_AI      // AI专用拍照
}