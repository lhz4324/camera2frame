package com.gtk.camera2frame.manager;

import android.os.Handler;
import android.os.HandlerThread;
import android.util.Log;

public class AutoCloseManager {
    private static final String TAG = "AutoCloseManager";
    private static final long DEFAULT_TIMEOUT = 30000; // 默认30秒
    
    private Handler mHandler;
    private long mTimeout = DEFAULT_TIMEOUT;
    private Runnable mAutoCloseRunnable;
    private AutoCloseCallback mCallback;

    public interface AutoCloseCallback {
        void onAutoClose();
    }

    public AutoCloseManager(AutoCloseCallback callback) {
        mCallback = callback;
        HandlerThread handlerThread = new HandlerThread("AutoCloseThread");
        handlerThread.start();
        mHandler = new Handler(handlerThread.getLooper());
        
        mAutoCloseRunnable = new Runnable() {
            @Override
            public void run() {
                Log.d(TAG, "Auto close timer triggered");
                if (mCallback != null) {
                    mCallback.onAutoClose();
                }
            }
        };
        
        Log.d(TAG, "AutoCloseManager initialized");
    }

    // 启动自动关闭定时器
    public void start() {
        Log.d(TAG, "start auto close timer");
        stop(); // 先停止之前的定时器
        mHandler.postDelayed(mAutoCloseRunnable, mTimeout);
    }

    // 停止自动关闭定时器
    public void stop() {
        Log.d(TAG, "stop auto close timer");
        mHandler.removeCallbacks(mAutoCloseRunnable);
    }

    // 重置自动关闭定时器
    public void reset() {
        Log.d(TAG, "reset auto close timer");
        start();
    }

    // 设置超时时间
    public void setTimeout(long timeout) {
        mTimeout = timeout;
        Log.d(TAG, "setTimeout: " + timeout + "ms");
    }

    // 释放资源
    public void release() {
        Log.d(TAG, "release");
        stop();
        if (mHandler != null) {
            mHandler.getLooper().quitSafely();
        }
    }
}