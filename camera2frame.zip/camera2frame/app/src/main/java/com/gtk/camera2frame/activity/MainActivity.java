package com.gtk.camera2frame.activity;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.IBinder;
import android.util.Log;
import android.view.TextureView;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.gtk.camera2frame.service.CameraServer;
import com.gtk.camera2frame.service.DataCommService;
import com.gtk.camera2frame.model.EventType;
import com.gtk.camera2frame.R;

public class MainActivity extends AppCompatActivity implements CameraServer.StatusCallback {
    private static final String TAG = "MainActivity";
    private static final int REQUEST_CAMERA_PERMISSION = 100;

    private Button mButtonStartService;
    private Button mButtonOpenCamera;
    private Button mButtonTakePicture;
    private Button mButtonStopService;
    private TextView mStatusText;
    private TextureView mTextureView;
    
    // 用于绑定CameraServer服务
    private CameraServer mCameraServer;
    private boolean mBound = false;
    private ServiceConnection mServiceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName className, IBinder service) {
            Log.d(TAG, "onServiceConnected");
            // 获取CameraServer实例
            CameraServer.LocalBinder binder = (CameraServer.LocalBinder) service;
            mCameraServer = binder.getService();
            mBound = true;
            
            // 设置状态回调
            if (mCameraServer != null) {
                Log.d(TAG, "Setting StatusCallback to CameraServer");
                mCameraServer.setStatusCallback(MainActivity.this);
            }
            
            // 设置TextureView
            if (mCameraServer != null && mTextureView != null) {
                Log.d(TAG, "Setting TextureView to CameraServer");
                mCameraServer.setTextureView(mTextureView);
                updateStatus("CameraServer bound, TextureView set");
                // 不再自动打开相机，只有点击Open Camera按钮才打开
                Log.d(TAG, "Service bound, ready to open camera");
            }
        }

        @Override
        public void onServiceDisconnected(ComponentName className) {
            Log.d(TAG, "onServiceDisconnected");
            mCameraServer = null;
            mBound = false;
            updateStatus("CameraServer disconnected");
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // 检查相机权限
        checkCameraPermission();

        // 初始化UI组件
        initUI();
    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.d(TAG, "onStart");
        // 不再自动绑定Service，只在启动Service后才绑定
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.d(TAG, "onStop");
        // 解绑CameraServer服务
        if (mBound) {
            unbindService(mServiceConnection);
            mBound = false;
        }
    }

    // 检查相机权限
    private void checkCameraPermission() {
        Log.d(TAG, "checkCameraPermission");
        // 检查相机权限
        if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            Log.d(TAG, "Camera permission not granted, requesting");
            ActivityCompat.requestPermissions(this, new String[]{android.Manifest.permission.CAMERA}, REQUEST_CAMERA_PERMISSION);
        } else {
            Log.d(TAG, "Camera permission already granted");
        }
        
        // 检查存储权限
        if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            Log.d(TAG, "Storage permission not granted, requesting");
            ActivityCompat.requestPermissions(this, new String[]{android.Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQUEST_CAMERA_PERMISSION + 1);
        } else {
            Log.d(TAG, "Storage permission already granted");
        }
        
        // 检查前台服务权限
        if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.FOREGROUND_SERVICE_CAMERA) != PackageManager.PERMISSION_GRANTED) {
            Log.d(TAG, "Foreground service camera permission not granted, requesting");
            ActivityCompat.requestPermissions(this, new String[]{android.Manifest.permission.FOREGROUND_SERVICE_CAMERA}, REQUEST_CAMERA_PERMISSION + 2);
        } else {
            Log.d(TAG, "Foreground service camera permission already granted");
        }
    }

    // 处理权限请求结果
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_CAMERA_PERMISSION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Log.d(TAG, "Camera permission granted");
                updateStatus("Camera permission granted");
            } else {
                Log.d(TAG, "Camera permission denied");
                updateStatus("Camera permission denied");
            }
        }
    }

    // 初始化UI组件
    private void initUI() {
        mTextureView = findViewById(R.id.texture_view);
        mStatusText = findViewById(R.id.status_text);
        mButtonStartService = findViewById(R.id.button_start_service);
        mButtonOpenCamera = findViewById(R.id.button_open_camera);
        mButtonTakePicture = findViewById(R.id.button_take_picture);
        mButtonStopService = findViewById(R.id.button_stop_service);

        // 设置点击监听器
        mButtonStartService.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startService();
            }
        });

        mButtonOpenCamera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openCamera();
            }
        });

        mButtonTakePicture.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                takePicture();
            }
        });

        mButtonStopService.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stopService();
            }
        });

        updateStatus("Ready to test");
    }

    // 启动服务
    private void startService() {
        Log.d(TAG, "startService");
        // 启动DataCommService
        Intent serviceIntent = new Intent(this, DataCommService.class);
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            startForegroundService(serviceIntent);
        } else {
            startService(serviceIntent);
        }
        updateStatus("Service started");
        Log.d(TAG, "DataCommService started");
        
        // 启动CameraServer
        Intent serverIntent = new Intent(this, CameraServer.class);
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            startForegroundService(serverIntent);
        } else {
            startService(serverIntent);
        }
        Log.d(TAG, "CameraServer started");
        
        // 绑定到CameraServer
        bindService(serverIntent, mServiceConnection, Context.BIND_AUTO_CREATE);
        Log.d(TAG, "Binding to CameraServer");
    }

    // 打开相机
    private void openCamera() {
        Log.d(TAG, "openCamera");
        
        // 检查服务是否已经绑定
        if (!mBound || mCameraServer == null) {
            Log.d(TAG, "Service not bound yet, starting and binding service");
            // 启动并绑定服务
            startService();
            updateStatus("Starting and binding service");
        } else {
            Log.d(TAG, "Service is bound, calling openCamera");
            // 服务已经绑定，直接调用openCamera方法
            mCameraServer.openCamera();
            updateStatus("Opening camera");
        }
        
        Log.d(TAG, "Camera opening, TextureView: " + mTextureView + ", bound: " + mBound + ", cameraServer: " + mCameraServer);
    }

    // 拍照
    private void takePicture() {
        Log.d(TAG, "takePicture");
        
        // 检查服务是否已经绑定
        if (!mBound || mCameraServer == null) {
            Log.d(TAG, "Service not bound yet, starting and binding service");
            // 启动并绑定服务
            startService();
            updateStatus("Starting and binding service");
        } else {
            Log.d(TAG, "Service is bound, calling takePictureOnly");
            // 服务已经绑定，直接调用takePictureOnly方法
            mCameraServer.takePictureOnly(EventType.PICTURE);
            updateStatus("Taking picture");
        }
        
        Log.d(TAG, "Taking picture, bound: " + mBound + ", cameraServer: " + mCameraServer);
    }

    // 停止服务
    private void stopService() {
        Log.d(TAG, "stopService");
        
        // 解绑服务
        if (mBound) {
            unbindService(mServiceConnection);
            mBound = false;
            Log.d(TAG, "Service unbound");
        }
        
        // 停止CameraServer
        Intent serverIntent = new Intent(this, CameraServer.class);
        stopService(serverIntent);
        Log.d(TAG, "CameraServer stopped");
        
        // 停止DataCommService
        Intent serviceIntent = new Intent(this, DataCommService.class);
        stopService(serviceIntent);
        Log.d(TAG, "DataCommService stopped");
        
        updateStatus("Service stopped");
    }

    // 更新状态文本
    private void updateStatus(String status) {
        Log.d(TAG, "Status: " + status);
        mStatusText.setText(status);
    }

    // 实现StatusCallback接口
    @Override
    public void onStatusChanged(String status) {
        Log.d(TAG, "onStatusChanged: " + status);
        // 在UI线程上更新状态
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                updateStatus(status);
            }
        });
    }
}