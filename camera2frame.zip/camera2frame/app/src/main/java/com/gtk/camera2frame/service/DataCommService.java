package com.gtk.camera2frame.service;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.IBinder;
import android.util.Log;
import com.gtk.camera2frame.R;

public class DataCommService extends Service {
    private static final String TAG = "DataCommService";
    private static final String CHANNEL_ID = "DataCommServiceChannel";
    private static final int NOTIFICATION_ID = 1;

    @Override
    public void onCreate() {
        super.onCreate();
        Log.d(TAG, "onCreate");
        createNotificationChannel();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Log.d(TAG, "onStartCommand");

        // 检查相机权限
        if (checkCameraPermission()) {
            // 启动前台服务
            startForeground(NOTIFICATION_ID, createNotification());

            // 启动相机服务管理器
            Intent cameraServerIntent = new Intent(this, CameraServer.class);
            startService(cameraServerIntent);
            Log.d(TAG, "CameraServer started");
        } else {
            Log.e(TAG, "Camera permission not granted, cannot start foreground service");
        }

        return START_STICKY;
    }

    // 检查相机权限
    private boolean checkCameraPermission() {
        Log.d(TAG, "checkCameraPermission");
        int cameraPermission = checkSelfPermission(android.Manifest.permission.CAMERA);
        int foregroundServiceCameraPermission = checkSelfPermission(android.Manifest.permission.FOREGROUND_SERVICE_CAMERA);
        
        boolean hasCameraPermission = cameraPermission == PackageManager.PERMISSION_GRANTED;
        boolean hasForegroundServiceCameraPermission = foregroundServiceCameraPermission == PackageManager.PERMISSION_GRANTED;
        
        Log.d(TAG, "hasCameraPermission: " + hasCameraPermission);
        Log.d(TAG, "hasForegroundServiceCameraPermission: " + hasForegroundServiceCameraPermission);
        
        return hasCameraPermission && hasForegroundServiceCameraPermission;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    "DataCommService",
                    NotificationManager.IMPORTANCE_LOW
            );
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) {
                manager.createNotificationChannel(channel);
            }
        }
    }

    private Notification createNotification() {
        Notification.Builder builder;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            builder = new Notification.Builder(this, CHANNEL_ID);
        } else {
            builder = new Notification.Builder(this);
        }

        return builder
                .setContentTitle("Camera Service")
                .setContentText("Running")
                .setSmallIcon(R.mipmap.ic_launcher)
                .setOngoing(true)
                .build();
    }
}