package com.gtk.camera2frame.receiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.media.AudioManager;
import android.media.session.MediaSessionManager;
import android.os.Build;
import android.util.Log;
import android.view.KeyEvent;
import com.gtk.camera2frame.service.CameraServer;

public class KeyReceiver extends BroadcastReceiver {
    private static final String TAG = "KeyReceiver";
    private CameraServer mCameraServer;

    public KeyReceiver(Context context) {
        // 这里可以获取CameraServer实例
        // 暂时保存Context引用
        Log.d(TAG, "KeyReceiver initialized");
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        String action = intent.getAction();
        Log.d(TAG, "onReceive: action=" + action);

        if (Intent.ACTION_MEDIA_BUTTON.equals(action)) {
            KeyEvent event = intent.getParcelableExtra(Intent.EXTRA_KEY_EVENT);
            if (event != null && event.getAction() == KeyEvent.ACTION_DOWN) {
                int keyCode = event.getKeyCode();
                Log.d(TAG, "Key pressed: " + keyCode);

                // 处理按键事件
                handleKeyEvent(keyCode, context);
            }
        }
    }

    // 处理按键事件
    private void handleKeyEvent(int keyCode, Context context) {
        Log.d(TAG, "handleKeyEvent: keyCode=" + keyCode);

        switch (keyCode) {
            case KeyEvent.KEYCODE_CAMERA:
            case KeyEvent.KEYCODE_FOCUS:
                // 对焦键或相机键，打开相机预览
                Log.d(TAG, "Camera/Focus key pressed, opening camera");
                openCamera(context);
                break;
            case KeyEvent.KEYCODE_VOLUME_UP:
            case KeyEvent.KEYCODE_VOLUME_DOWN:
                // 音量键，拍照
                Log.d(TAG, "Volume key pressed, taking picture");
                takePicture(context);
                break;
            default:
                Log.d(TAG, "Unknown key pressed: " + keyCode);
                break;
        }
    }

    // 打开相机
    private void openCamera(Context context) {
        // 启动CameraServer并打开相机
        Intent serverIntent = new Intent(context, CameraServer.class);
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            context.startForegroundService(serverIntent);
        } else {
            context.startService(serverIntent);
        }
        
        // 这里需要获取CameraServer实例并调用openCamera方法
        // 由于BroadcastReceiver的生命周期限制，实际实现中可能需要通过其他方式获取CameraServer实例
        Log.d(TAG, "Requesting camera open");
    }

    // 拍照
    private void takePicture(Context context) {
        // 启动CameraServer并拍照
        Intent serverIntent = new Intent(context, CameraServer.class);
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            context.startForegroundService(serverIntent);
        } else {
            context.startService(serverIntent);
        }
        
        // 这里需要获取CameraServer实例并调用takePictureOnly方法
        // 由于BroadcastReceiver的生命周期限制，实际实现中可能需要通过其他方式获取CameraServer实例
        Log.d(TAG, "Requesting picture capture");
    }
}