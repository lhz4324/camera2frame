package com.gtk.camera2frame.service;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.hardware.Sensor;
import android.hardware.SensorManager;
import android.os.Binder;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.util.Log;
import android.view.TextureView;
import com.gtk.camera2frame.activity.MainActivity;
import com.gtk.camera2frame.controller.CameraController;
import com.gtk.camera2frame.manager.CheckManager;
import com.gtk.camera2frame.model.EventType;
import com.gtk.camera2frame.receiver.KeyReceiver;

public class CameraServer extends Service {
    private static final String TAG = "CameraServer";

    // Binder given to clients
    private final IBinder mBinder = new LocalBinder();

    // 用于存储绑定的客户端
    private MainActivity mActivity;
    private StatusCallback mStatusCallback;

    // 状态回调接口
    public interface StatusCallback {
        void onStatusChanged(String status);
    }

    // 设置状态回调
    public void setStatusCallback(StatusCallback callback) {
        mStatusCallback = callback;
    }

    // 发送状态更新
    private void updateStatus(String status) {
        Log.d(TAG, "Status: " + status);
        if (mStatusCallback != null) {
            mStatusCallback.onStatusChanged(status);
        }
    }

    // 本地Binder类
    public class LocalBinder extends Binder {
        public CameraServer getService() {
            // 返回当前服务实例，以便客户端可以调用其公共方法
            return CameraServer.this;
        }
    }

    private HandlerThread mHandlerThread;
    private Handler mHandler;
    private CameraController mCameraController;
    private CheckManager mCheckManager;
    private KeyReceiver mKeyReceiver;
    private SensorManager mSensorManager;
    private Sensor mProximitySensor;

    @Override
    public void onCreate() {
        super.onCreate();
        Log.d(TAG, "onCreate");

        // 创建Handler线程
        mHandlerThread = new HandlerThread("CameraServerThread");
        mHandlerThread.start();
        mHandler = new Handler(mHandlerThread.getLooper());

        // 创建CameraController
        mCameraController = new CameraController(this);
        mCameraController.init();

        // 初始化CheckManager
        mCheckManager = new CheckManager(this);

        // 注册KeyReceiver
        mKeyReceiver = new KeyReceiver(this);
        IntentFilter filter = new IntentFilter();
        filter.addAction(Intent.ACTION_MEDIA_BUTTON);
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(mKeyReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(mKeyReceiver, filter);
        }

        // 注册接近传感器
        mSensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        mProximitySensor = mSensorManager.getDefaultSensor(Sensor.TYPE_PROXIMITY);
        if (mProximitySensor != null) {
            Log.d(TAG, "Proximity sensor registered");
        }

        Log.d(TAG, "CameraServer initialized");
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Log.d(TAG, "onStartCommand");
        return START_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) {
        Log.d(TAG, "onBind");
        return mBinder;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.d(TAG, "onDestroy");

        // 取消注册KeyReceiver
        if (mKeyReceiver != null) {
            unregisterReceiver(mKeyReceiver);
        }

        // 停止Handler线程
        if (mHandlerThread != null) {
            mHandlerThread.quitSafely();
        }

        // 释放CameraController
        if (mCameraController != null) {
            mCameraController.release();
        }
    }

    // 打开相机预览
    public void openCamera() {
        Log.d(TAG, "openCamera");
        updateStatus("Opening camera preview");
        if (mCameraController != null) {
            mCameraController.startPreviewOnly(EventType.START_PREVIEW);
            updateStatus("Camera preview started");
        } else {
            updateStatus("CameraController not initialized");
        }
    }

    // 拍照
    public void takePictureOnly(EventType eventType) {
        Log.d(TAG, "takePictureOnly: eventType=" + eventType);
        updateStatus("Preparing to take picture");
        if (mCameraController != null) {
            // 检查相机就绪状态
            if (mCameraController.checkStateReadyForEvent(eventType)) {
                // 检查拍照条件
                if (mCheckManager.checkConditions()) {
                    updateStatus("Taking picture");
                    mCameraController.takePicture();
                    updateStatus("Picture taken, saving...");
                } else {
                    updateStatus("Picture conditions not met");
                }
            } else {
                updateStatus("Camera not ready for picture");
            }
        } else {
            updateStatus("CameraController not initialized");
        }
    }

    // 获取CameraController
    public CameraController getCameraController() {
        return mCameraController;
    }

    // 获取CheckManager
    public CheckManager getCheckManager() {
        return mCheckManager;
    }

    // 设置TextureView
    public void setTextureView(TextureView textureView) {
        Log.d(TAG, "setTextureView");
        if (mCameraController != null) {
            mCameraController.setTextureView(textureView);
        }
    }
}