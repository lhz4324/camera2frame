package com.gtk.camera2frame.controller;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CaptureRequest;
import android.hardware.camera2.CaptureResult;
import android.hardware.camera2.TotalCaptureResult;
import android.media.Image;
import android.media.ImageReader;
import android.net.Uri;
import android.os.Environment;
import android.os.Handler;
import android.os.HandlerThread;
import android.util.Log;
import android.util.Size;
import android.view.Surface;
import android.view.TextureView;
import android.graphics.SurfaceTexture;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.Semaphore;
import java.util.concurrent.TimeUnit;

import com.gtk.camera2frame.manager.AutoCloseManager;
import com.gtk.camera2frame.model.EventType;
import com.gtk.camera2frame.model.CameraState;

public class CameraController implements AutoCloseManager.AutoCloseCallback, TextureView.SurfaceTextureListener {
    private static final String TAG = "CameraController";
    private static final int MAX_PREVIEW_WIDTH = 1920;
    private static final int MAX_PREVIEW_HEIGHT = 1080;
    private static final int MAX_CAPTURE_WIDTH = 4032;
    private static final int MAX_CAPTURE_HEIGHT = 3024;
    private static final int IMAGE_BUFFER_SIZE = 3;

    private Context mContext;
    private TextureView mTextureView;
    private CameraManager mCameraManager;
    private CameraDevice mCameraDevice;
    private CameraCaptureSession mCaptureSession;
    private CaptureRequest.Builder mPreviewRequestBuilder;
    private CaptureRequest mPreviewRequest;
    private ImageReader mPreviewImageReader; // 预览用ImageReader
    private ImageReader mCaptureImageReader; // 拍照用ImageReader
    private Size mPreviewSize;
    private Size mCaptureSize;
    private String mCameraId;
    private HandlerThread mBackgroundThread;
    private Handler mBackgroundHandler;
    private AutoCloseManager mAutoCloseManager;
    private Semaphore mCameraOpenLock = new Semaphore(1);
    private CameraState mCameraState = CameraState.NONE;
    private EventType mCurrentEvent = EventType.NONE;
    private boolean mTakePictureWhenReady = false;
    private boolean mSurfaceTextureReady = false;

    public CameraController(Context context) {
        mContext = context;
        Log.d(TAG, "CameraController created");
    }

    // 设置TextureView
    public void setTextureView(TextureView textureView) {
        Log.d(TAG, "setTextureView");
        mTextureView = textureView;
        if (mTextureView != null) {
            mTextureView.setSurfaceTextureListener(this);
            mSurfaceTextureReady = mTextureView.isAvailable();
            Log.d(TAG, "SurfaceTexture ready: " + mSurfaceTextureReady);
        }
    }

    // 初始化相机控制器
    public void init() {
        Log.d(TAG, "init");
        
        // 获取CameraManager
        mCameraManager = (CameraManager) mContext.getSystemService(Context.CAMERA_SERVICE);
        
        // 启动后台线程
        startBackgroundThread();
        
        // 初始化AutoCloseManager
        mAutoCloseManager = new AutoCloseManager(this);
        
        // 读取配置文件（这里可以添加配置文件读取逻辑）
        
        // 创建存储目录（这里可以添加存储目录创建逻辑）
        
        Log.d(TAG, "CameraController initialized");
    }

    // 启动预览
    public void startPreviewOnly(EventType eventType) {
        Log.d(TAG, "startPreviewOnly: eventType=" + eventType);
        
        // 检查状态
        if (!checkStateReadyForEvent(eventType)) {
            Log.e(TAG, "Camera not ready for event: " + eventType);
            return;
        }
        
        // 启动自动关闭定时器
        mAutoCloseManager.start();
        
        // 设置当前事件
        mCurrentEvent = eventType;
        
        // 打开相机设备
        openCameraDevice();
    }

    // 拍照
    public void takePicture() {
        Log.d(TAG, "takePicture");
        
        // 停止自动关闭定时器
        mAutoCloseManager.stop();
        
        // 检查相机状态
        switch (mCameraState) {
            case INIT:
                // 正在初始化，标记等待标志
                mTakePictureWhenReady = true;
                Log.d(TAG, "Camera is initializing, will take picture when ready");
                break;
            case PREVIEW:
                // 正在预览，立即拍照
                cameraControllerStillPicture();
                break;
            default:
                // 其他状态，先打开相机再拍照
                mTakePictureWhenReady = true;
                openCameraDevice();
                break;
        }
    }

    // 检查状态是否就绪
    public boolean checkStateReadyForEvent(EventType eventType) {
        Log.d(TAG, "checkStateReadyForEvent: eventType=" + eventType + ", currentState=" + mCameraState);
        
        // 这里可以添加各种状态检查
        // 例如：权限检查、设备状态检查等
        
        // 暂时返回true，表示检查通过
        return true;
    }

    // 打开相机设备
    private void openCameraDevice() {
        Log.d(TAG, "openCameraDevice");
        
        if (!mCameraOpenLock.tryAcquire()) {
            Log.e(TAG, "Camera already opening");
            return;
        }
        
        try {
            // 获取相机ID
            String[] cameraIds = mCameraManager.getCameraIdList();
            if (cameraIds.length == 0) {
                Log.e(TAG, "No cameras available");
                mCameraOpenLock.release();
                return;
            }
            mCameraId = cameraIds[0]; // 使用默认相机
            
            // 配置输出
            setUpCameraOutputs();
            
            // 打开相机
            mCameraManager.openCamera(mCameraId, mStateCallback, mBackgroundHandler);
            mCameraState = CameraState.INIT;
            
        } catch (CameraAccessException e) {
            Log.e(TAG, "Camera access exception: " + e.getMessage());
            mCameraOpenLock.release();
        } catch (SecurityException e) {
            Log.e(TAG, "Security exception: " + e.getMessage());
            mCameraOpenLock.release();
        }
    }

    // 配置相机输出
    private void setUpCameraOutputs() {
        Log.d(TAG, "setUpCameraOutputs");
        
        try {
            // 获取相机特性
            CameraCharacteristics characteristics = mCameraManager.getCameraCharacteristics(mCameraId);
            
            // 选择预览尺寸
            Size[] previewSizes = characteristics.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
                    .getOutputSizes(Surface.class);
            mPreviewSize = chooseOptimalSize(previewSizes, MAX_PREVIEW_WIDTH, MAX_PREVIEW_HEIGHT);
            Log.d(TAG, "Preview size: " + mPreviewSize.getWidth() + "x" + mPreviewSize.getHeight());
            
            // 选择拍照尺寸
            Size[] captureSizes = characteristics.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
                    .getOutputSizes(android.graphics.ImageFormat.JPEG);
            mCaptureSize = chooseOptimalSize(captureSizes, MAX_CAPTURE_WIDTH, MAX_CAPTURE_HEIGHT);
            Log.d(TAG, "Capture size: " + mCaptureSize.getWidth() + "x" + mCaptureSize.getHeight());
            
            // 创建预览用ImageReader（小尺寸，用于实时预览）
            mPreviewImageReader = ImageReader.newInstance(
                    mPreviewSize.getWidth(),
                    mPreviewSize.getHeight(),
                    android.graphics.ImageFormat.YUV_420_888,
                    1
            );
            
            // 创建拍照用ImageReader（大尺寸，用于高质量拍照）
            mCaptureImageReader = ImageReader.newInstance(
                    mCaptureSize.getWidth(),
                    mCaptureSize.getHeight(),
                    android.graphics.ImageFormat.JPEG,
                    IMAGE_BUFFER_SIZE
            );
            mCaptureImageReader.setOnImageAvailableListener(mCaptureOnImageAvailableListener, mBackgroundHandler);
            
        } catch (CameraAccessException e) {
            Log.e(TAG, "Camera access exception: " + e.getMessage());
        }
    }

    // 选择最佳预览尺寸
    private Size chooseOptimalSize(Size[] choices, int width, int height) {
        Log.d(TAG, "chooseOptimalSize: choices=" + choices + ", width=" + width + ", height=" + height);
        
        if (choices == null || choices.length == 0) {
            Log.e(TAG, "choices is null or empty, returning default size");
            return new Size(1920, 1080);
        }
        
        List<Size> bigEnough = new ArrayList<>();
        for (Size option : choices) {
            if (option != null && option.getHeight() <= height && option.getWidth() <= width) {
                bigEnough.add(option);
            }
        }
        
        if (bigEnough.size() > 0) {
            return Collections.max(bigEnough, (s1, s2) -> s1.getWidth() * s1.getHeight() - s2.getWidth() * s2.getHeight());
        } else {
            Log.w(TAG, "No optimal size found, returning first choice");
            return choices[0];
        }
    }

    // 创建相机预览会话
    private void createCameraPreviewSession() {
        Log.d(TAG, "createCameraPreviewSession");
        
        if (!mSurfaceTextureReady || mTextureView == null) {
            Log.e(TAG, "SurfaceTexture not ready or TextureView is null");
            return;
        }
        
        try {
            // 获取SurfaceTexture
            SurfaceTexture surfaceTexture = mTextureView.getSurfaceTexture();
            if (surfaceTexture == null) {
                Log.e(TAG, "SurfaceTexture is null");
                return;
            }
            
            // 设置预览大小
            surfaceTexture.setDefaultBufferSize(mPreviewSize.getWidth(), mPreviewSize.getHeight());
            
            // 创建预览表面
            Surface previewSurface = new Surface(surfaceTexture);
            
            // 创建预览请求构建器
            mPreviewRequestBuilder = mCameraDevice.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW);
            mPreviewRequestBuilder.addTarget(previewSurface);
            
            // 创建捕获会话（只包含预览表面，不包含拍照的ImageReader）
            List<Surface> surfaces = new ArrayList<>();
            surfaces.add(previewSurface);
            
            mCameraDevice.createCaptureSession(
                    surfaces,
                    mCaptureSessionCallback,
                    mBackgroundHandler
            );
            
        } catch (CameraAccessException e) {
            Log.e(TAG, "Camera access exception: " + e.getMessage());
        }
    }

    // 拍照处理
    private void cameraControllerStillPicture() {
        Log.d(TAG, "cameraControllerStillPicture");
        
        try {
            // 播放快门音
            // 这里可以添加播放快门音的代码
            
            // 生成文件名
            String fileName = generateFileName();
            Log.d(TAG, "Picture file name: " + fileName);
            
            // 等待3A稳定
            // 这里可以添加等待3A稳定的代码
            
            // 创建拍照专用的捕获会话
            createCaptureSession();
            
        } catch (CameraAccessException e) {
            Log.e(TAG, "Camera access exception: " + e.getMessage());
        }
    }

    // 创建拍照专用的捕获会话
    private void createCaptureSession() throws CameraAccessException {
        Log.d(TAG, "createCaptureSession for high quality capture");
        
        if (mCameraDevice == null || mCaptureImageReader == null) {
            Log.e(TAG, "CameraDevice or CaptureImageReader is null");
            return;
        }
        
        // 获取TextureView的Surface
        SurfaceTexture surfaceTexture = mTextureView.getSurfaceTexture();
        if (surfaceTexture == null) {
            Log.e(TAG, "SurfaceTexture is null");
            return;
        }
        surfaceTexture.setDefaultBufferSize(mPreviewSize.getWidth(), mPreviewSize.getHeight());
        Surface previewSurface = new Surface(surfaceTexture);
        
        // 获取拍照ImageReader的Surface
        Surface captureSurface = mCaptureImageReader.getSurface();
        
        // 创建表面列表
        List<Surface> surfaces = new ArrayList<>();
        surfaces.add(previewSurface);
        surfaces.add(captureSurface);
        
        // 创建捕获会话
        mCameraDevice.createCaptureSession(
                surfaces,
                new CameraCaptureSession.StateCallback() {
                    @Override
                    public void onConfigured(CameraCaptureSession session) {
                        Log.d(TAG, "Capture session configured for high quality capture");
                        try {
                            // 创建拍照请求
                            CaptureRequest.Builder captureBuilder = mCameraDevice.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE);
                            captureBuilder.addTarget(captureSurface);
                            
                            // 设置高质量拍照参数
                            captureBuilder.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE);
                            captureBuilder.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_ON_AUTO_FLASH);
                            captureBuilder.set(CaptureRequest.CONTROL_AWB_MODE, CaptureRequest.CONTROL_AWB_MODE_AUTO);
                            captureBuilder.set(CaptureRequest.JPEG_QUALITY, (byte) 100);
                            
                            // 发送拍照请求
                            session.capture(captureBuilder.build(), new CameraCaptureSession.CaptureCallback() {
                                @Override
                                public void onCaptureCompleted(CameraCaptureSession session, CaptureRequest request, TotalCaptureResult result) {
                                    Log.d(TAG, "High quality capture completed");
                                    mCameraState = CameraState.PICTURE;
                                    
                                    // 恢复预览
                                    try {
                                        createCameraPreviewSession();
                                    } catch (Exception e) {
                                        Log.e(TAG, "Error restoring preview: " + e.getMessage());
                                    }
                                }
                            }, mBackgroundHandler);
                        } catch (CameraAccessException e) {
                            Log.e(TAG, "Camera access exception: " + e.getMessage());
                        }
                    }

                    @Override
                    public void onConfigureFailed(CameraCaptureSession session) {
                        Log.e(TAG, "Capture session configure failed");
                    }
                },
                mBackgroundHandler
        );
    }

    // 生成文件名
    private String generateFileName() {
        return "IMG_" + System.currentTimeMillis() + ".jpg";
    }

    // 启动后台线程
    private void startBackgroundThread() {
        mBackgroundThread = new HandlerThread("CameraBackground");
        mBackgroundThread.start();
        mBackgroundHandler = new Handler(mBackgroundThread.getLooper());
    }

    // 停止后台线程
    private void stopBackgroundThread() {
        if (mBackgroundThread != null) {
            mBackgroundThread.quitSafely();
            try {
                mBackgroundThread.join();
                mBackgroundThread = null;
                mBackgroundHandler = null;
            } catch (InterruptedException e) {
                Log.e(TAG, "InterruptedException: " + e.getMessage());
            }
        }
    }

    // 释放资源
    public void release() {
        Log.d(TAG, "release");
        
        // 释放相机设备
        if (mCameraDevice != null) {
            mCameraDevice.close();
            mCameraDevice = null;
        }
        
        // 释放捕获会话
        if (mCaptureSession != null) {
            mCaptureSession.close();
            mCaptureSession = null;
        }
        
        // 释放预览ImageReader
        if (mPreviewImageReader != null) {
            mPreviewImageReader.close();
            mPreviewImageReader = null;
        }
        
        // 释放拍照ImageReader
        if (mCaptureImageReader != null) {
            mCaptureImageReader.close();
            mCaptureImageReader = null;
        }
        
        // 释放AutoCloseManager
        if (mAutoCloseManager != null) {
            mAutoCloseManager.release();
            mAutoCloseManager = null;
        }
        
        // 停止后台线程
        stopBackgroundThread();
        
        // 释放锁
        mCameraOpenLock.release();
        
        mCameraState = CameraState.NONE;
        Log.d(TAG, "CameraController released");
    }

    // 自动关闭回调
    @Override
    public void onAutoClose() {
        Log.d(TAG, "onAutoClose");
        // 自动关闭相机
        release();
    }

    // SurfaceTexture可用回调
    @Override
    public void onSurfaceTextureAvailable(SurfaceTexture surface, int width, int height) {
        Log.d(TAG, "onSurfaceTextureAvailable: width=" + width + ", height=" + height);
        mSurfaceTextureReady = true;
        // 如果相机已经初始化，创建预览会话
        if (mCameraDevice != null) {
            createCameraPreviewSession();
        }
    }

    // SurfaceTexture大小改变回调
    @Override
    public void onSurfaceTextureSizeChanged(SurfaceTexture surface, int width, int height) {
        Log.d(TAG, "onSurfaceTextureSizeChanged: width=" + width + ", height=" + height);
        // 处理预览大小变化
    }

    // SurfaceTexture销毁回调
    @Override
    public boolean onSurfaceTextureDestroyed(SurfaceTexture surface) {
        Log.d(TAG, "onSurfaceTextureDestroyed");
        mSurfaceTextureReady = false;
        return true;
    }

    // SurfaceTexture更新回调
    @Override
    public void onSurfaceTextureUpdated(SurfaceTexture surface) {
        // 预览帧更新时调用，通常不需要处理
    }

    // 相机状态回调
    private CameraDevice.StateCallback mStateCallback = new CameraDevice.StateCallback() {
        @Override
        public void onOpened(CameraDevice camera) {
            Log.d(TAG, "Camera onOpened");
            mCameraDevice = camera;
            mCameraOpenLock.release();
            createCameraPreviewSession();
        }

        @Override
        public void onDisconnected(CameraDevice camera) {
            Log.d(TAG, "Camera onDisconnected");
            mCameraOpenLock.release();
            camera.close();
            mCameraDevice = null;
        }

        @Override
        public void onError(CameraDevice camera, int error) {
            Log.e(TAG, "Camera onError: " + error);
            mCameraOpenLock.release();
            camera.close();
            mCameraDevice = null;
        }
    };

    // 捕获会话回调
    private CameraCaptureSession.StateCallback mCaptureSessionCallback = new CameraCaptureSession.StateCallback() {
        @Override
        public void onConfigured(CameraCaptureSession session) {
            Log.d(TAG, "Capture session onConfigured");
            mCaptureSession = session;
            
            try {
                // 设置预览请求
                mPreviewRequestBuilder.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE);
                mPreviewRequestBuilder.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_ON_AUTO_FLASH);
                mPreviewRequest = mPreviewRequestBuilder.build();
                
                // 开始预览
                mCaptureSession.setRepeatingRequest(mPreviewRequest, mCaptureCallback, mBackgroundHandler);
                mCameraState = CameraState.PREVIEW;
                Log.d(TAG, "Preview started");
                
                // 如果需要拍照
                if (mTakePictureWhenReady) {
                    mTakePictureWhenReady = false;
                    cameraControllerStillPicture();
                }
                
            } catch (CameraAccessException e) {
                Log.e(TAG, "Camera access exception: " + e.getMessage());
            }
        }

        @Override
        public void onConfigureFailed(CameraCaptureSession session) {
            Log.e(TAG, "Capture session configure failed");
        }
    };

    // 捕获回调
    private CameraCaptureSession.CaptureCallback mCaptureCallback = new CameraCaptureSession.CaptureCallback() {
        @Override
        public void onCaptureCompleted(CameraCaptureSession session, CaptureRequest request, TotalCaptureResult result) {
            Log.d(TAG, "Capture completed");
            
            // 恢复预览
            try {
                mCaptureSession.setRepeatingRequest(mPreviewRequest, null, mBackgroundHandler);
                mCameraState = CameraState.PREVIEW;
                
                // 重启自动关闭定时器
                mAutoCloseManager.start();
                
            } catch (CameraAccessException e) {
                Log.e(TAG, "Camera access exception: " + e.getMessage());
            }
        }
    };

    // 预览图像可用回调（不保存图像）
    private ImageReader.OnImageAvailableListener mPreviewOnImageAvailableListener = new ImageReader.OnImageAvailableListener() {
        @Override
        public void onImageAvailable(ImageReader reader) {
            Log.d(TAG, "Preview image available, skipping save");
            // 预览图像不保存，直接释放
            Image image = reader.acquireLatestImage();
            if (image != null) {
                image.close();
            }
        }
    };

    // 拍照图像可用回调（保存高质量图像）
    private ImageReader.OnImageAvailableListener mCaptureOnImageAvailableListener = new ImageReader.OnImageAvailableListener() {
        @Override
        public void onImageAvailable(ImageReader reader) {
            Log.d(TAG, "Capture image available, saving high quality image");
            
            // 获取图像
            Image image = reader.acquireLatestImage();
            if (image == null) {
                return;
            }
            
            // 保存高质量图像
            new ImageSaver(image).start();
        }
    };

    // 图像保存线程
    private class ImageSaver extends Thread {
        private Image mImage;

        public ImageSaver(Image image) {
            mImage = image;
        }

        @Override
        public void run() {
            Log.d(TAG, "Saving high quality image");
            
            // 保存图像到文件
            saveImageToFile();
            
            // 释放图像
            mImage.close();
            Log.d(TAG, "High quality image saved");
        }

        // 保存图像到文件
        private void saveImageToFile() {
            Log.d(TAG, "saveImageToFile");
            
            if (mImage == null) {
                Log.e(TAG, "Image is null");
                return;
            }
            
            // 获取图像缓冲区
            Image.Plane[] planes = mImage.getPlanes();
            ByteBuffer buffer = planes[0].getBuffer();
            byte[] data = new byte[buffer.remaining()];
            buffer.get(data);
            
            // 生成文件名
            String fileName = generateFileName();
            Log.d(TAG, "Saving high quality image to file: " + fileName);
            
            try {
                // 创建存储目录（使用公共图片目录，确保在相册中可见）
                File storageDir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), "Camera2Frame");
                if (!storageDir.exists()) {
                    if (!storageDir.mkdirs()) {
                        Log.e(TAG, "Failed to create directory: " + storageDir.getAbsolutePath());
                        return;
                    }
                }
                Log.d(TAG, "Storage directory: " + storageDir.getAbsolutePath());
                
                // 创建文件
                File imageFile = new File(storageDir, fileName);
                FileOutputStream fos = new FileOutputStream(imageFile);
                fos.write(data);
                fos.close();
                Log.d(TAG, "High quality image saved to: " + imageFile.getAbsolutePath());
                
                // 将照片添加到相册
                addImageToGallery(imageFile.getAbsolutePath(), fileName);
                
            } catch (IOException e) {
                Log.e(TAG, "Error saving high quality image: " + e.getMessage());
            }
        }

        // 将照片添加到相册
        private void addImageToGallery(String imagePath, String title) {
            Log.d(TAG, "addImageToGallery: path=" + imagePath + ", title=" + title);
            
            // 通知系统扫描文件
            Intent mediaScanIntent = new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE);
            File f = new File(imagePath);
            Uri contentUri = Uri.fromFile(f);
            mediaScanIntent.setData(contentUri);
            mContext.sendBroadcast(mediaScanIntent);
            Log.d(TAG, "High quality image added to gallery");
        }
    }
}