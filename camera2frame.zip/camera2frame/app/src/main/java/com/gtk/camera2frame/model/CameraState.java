package com.gtk.camera2frame.model;

public enum CameraState {
    NONE,                   // 无状态
    CHECK,                 // 检查中
    INIT,                  // 初始化
    PREVIEW,              // 预览中
    PICTURE,              // 拍照中
    NORMAL_RECORD,        // 录像中
    NORMAL_RECORD_STOPPING // 录像停止中
}